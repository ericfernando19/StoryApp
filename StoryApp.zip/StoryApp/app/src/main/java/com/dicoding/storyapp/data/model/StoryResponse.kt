package com.dicoding.storyapp.data.model

import com.google.gson.annotations.SerializedName

data class StoryResponse(
    @field:SerializedName("listStory")
    val listStory: List<ListStoryItem> = emptyList()
)
