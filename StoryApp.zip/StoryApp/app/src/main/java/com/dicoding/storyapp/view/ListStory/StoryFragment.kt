package com.dicoding.storyapp.view.ListStory

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.storyapp.R
import com.dicoding.storyapp.data.model.ListStoryItem
import com.dicoding.storyapp.view.ListStory.Adapter.StoryAdapter
import com.dicoding.storyapp.view.ListStory.Detail.DetailActivity
import com.dicoding.storyapp.view.ListStory.ViewModel.StoryViewModel

class StoryFragment : Fragment() {

    private lateinit var adapter: StoryAdapter
    private lateinit var rvStories: RecyclerView
    private lateinit var viewModel: StoryViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_story, container, false)

        // Inisialisasi RecyclerView
        rvStories = view.findViewById(R.id.rv_stories)
        rvStories.layoutManager = LinearLayoutManager(requireContext())

        // Inisialisasi adapter
        adapter = StoryAdapter(object : StoryAdapter.OnItemClickCallback {
            override fun onItemClicked(story: ListStoryItem) {
                moveToDetail(story)
            }
        })
        rvStories.adapter = adapter

        // Inisialisasi ViewModel dan observasi data
        viewModel = ViewModelProvider(this).get(StoryViewModel::class.java)
        viewModel.getStories("your_token_here") // Masukkan token jika perlu
        viewModel.stories.observe(viewLifecycleOwner) { stories ->
            adapter.submitList(stories) // Submit data ke adapter
        }

        return view
    }

    private fun moveToDetail(story: ListStoryItem) {
        val intent = Intent(requireContext(), DetailActivity::class.java)
        intent.putExtra("STORY_ID", story.id) // Kirim ID story
        startActivity(intent)
    }
}
