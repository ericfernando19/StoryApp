package com.dicoding.storyapp.di

import android.content.Context
import com.dicoding.storyapp.data.Api.ApiConfig
import com.dicoding.storyapp.view.ListStory.StoryRepository
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.UserRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {

    // Menyediakan StoryRepository
    fun provideStoryRepository(context: Context): StoryRepository {
        val pref = UserPreference.getInstance(context)

        val token = runBlocking {
            pref.getSession().first().token
        }

        val apiService = ApiConfig.getApiService(token)

        return StoryRepository.getInstance(apiService, pref)
    }

    // Menyediakan UserRepository
    fun provideUserRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context)
        return UserRepository.getInstance(pref)
    }
}
