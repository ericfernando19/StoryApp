package com.dicoding.storyapp.data.auth


data class AuthResponse(
    val error: Boolean,
    val message: String,
    val token: String
)

