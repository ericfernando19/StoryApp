package com.dicoding.storyapp.view.ListStory.Detail

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.storyapp.R
import com.dicoding.storyapp.data.model.Story

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Mengambil data Story dari Intent
        val story: Story? = intent.getParcelableExtra("STORY")

        // Menghubungkan UI dengan ID
        val ivPhoto: ImageView = findViewById(R.id.iv_detail_photo)
        val tvName: TextView = findViewById(R.id.tv_detail_name)
        val tvDescription: TextView = findViewById(R.id.tv_detail_description)

        // Memastikan story tidak null sebelum di-bind ke UI
        story?.let {
            tvName.text = it.name
            tvDescription.text = it.description
            Glide.with(this).load(it.photoUrl).into(ivPhoto)
        } ?: run {
            // Jika data story null, beri penanganan fallback (misal tampilkan pesan error)
            tvName.text = getString(R.string.error_message)
            tvDescription.text = getString(R.string.error_message)
        }
    }
}
