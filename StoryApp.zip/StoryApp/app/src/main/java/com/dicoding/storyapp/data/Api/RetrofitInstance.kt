package com.dicoding.storyapp.data.api

import com.dicoding.storyapp.data.Api.ApiService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {

    private const val BASE_URL = "https://story-api.dicoding.dev/v1/"

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Perbaiki impor ApiService menjadi yang benar
    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}
