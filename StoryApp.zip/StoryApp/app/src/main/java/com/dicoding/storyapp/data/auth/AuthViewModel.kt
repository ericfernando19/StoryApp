package com.dicoding.storyapp.ui.auth

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.auth.AuthRepository
import com.dicoding.storyapp.data.auth.AuthResponse
import kotlinx.coroutines.launch
import retrofit2.Response

class AuthViewModel(private val authRepository: AuthRepository, private val context: Context) : ViewModel() {

    private val _loginResponse = MutableLiveData<AuthResponse>()
    val loginResponse: LiveData<AuthResponse> get() = _loginResponse

    private val _signupResponse = MutableLiveData<AuthResponse>()
    val signupResponse: LiveData<AuthResponse> get() = _signupResponse

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    // Fungsi untuk melakukan login
    fun login(email: String, password: String) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response: Response<AuthResponse> = authRepository.login(email, password)

                if (response.isSuccessful) {
                    val authResponse = response.body() ?: AuthResponse(
                        error = true,
                        message = "Login failed",
                        token = ""
                    )
                    _loginResponse.postValue(authResponse)
                    // Menyimpan token setelah login berhasil
                    saveToken(authResponse.token)
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                    val errorAuthResponse = AuthResponse(
                        error = true,
                        message = errorMessage,
                        token = ""
                    )
                    _loginResponse.postValue(errorAuthResponse)
                }
            } catch (e: Exception) {
                val errorAuthResponse = AuthResponse(
                    error = true,
                    message = "An unexpected error occurred",
                    token = ""
                )
                _loginResponse.postValue(errorAuthResponse)
                Log.e("AuthViewModel", "Login Error: ", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Fungsi untuk melakukan signup
    fun signup(name: String, email: String, password: String) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response: Response<AuthResponse> = authRepository.signup(name, email, password)

                if (response.isSuccessful) {
                    val authResponse = response.body() ?: AuthResponse(
                        error = false,
                        message = "Signup berhasil",
                        token = ""
                    )
                    _signupResponse.postValue(authResponse)
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Unknown error"
                    val errorAuthResponse = AuthResponse(
                        error = true,
                        message = errorMessage,
                        token = ""
                    )
                    _signupResponse.postValue(errorAuthResponse)
                }
            } catch (e: Exception) {
                val errorAuthResponse = AuthResponse(
                    error = true,
                    message = "An unexpected error occurred",
                    token = ""
                )
                _signupResponse.postValue(errorAuthResponse)
                Log.e("AuthViewModel", "Signup Error: ", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Simpan token ke SharedPreferences
    internal fun saveToken(token: String) {
        val sharedPreferences = context.getSharedPreferences("auth_preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("auth_token", token)
        editor.apply()
    }

    // Mengambil token dari SharedPreferences
    fun getToken(): String? {
        val sharedPreferences = context.getSharedPreferences("auth_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("auth_token", null)
    }
}
