package com.dicoding.storyapp.view.ListStory.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.model.ListStoryItem
import com.dicoding.storyapp.view.ListStory.StoryRepository
import kotlinx.coroutines.launch

class StoryViewModel(private val storyRepository: StoryRepository) : ViewModel() {

    private val _stories = MutableLiveData<List<ListStoryItem>>()
    val stories: LiveData<List<ListStoryItem>> get() = _stories

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> get() = _errorMessage

    fun getStories(token: String) {
        _isLoading.postValue(true) // Mulai loading
        viewModelScope.launch {
            try {
                val response = storyRepository.getStories(token)
                if (response.listStory != null) {
                    _stories.postValue(response.listStory)
                } else {
                    _errorMessage.postValue("Data kosong atau tidak valid.")
                }
            } catch (e: Exception) {
                _errorMessage.postValue("Error fetching stories: ${e.message}")
                Log.e("StoryViewModel", "Error fetching stories", e)
            } finally {
                _isLoading.postValue(false) // Selesai loading
            }
        }
    }
}
