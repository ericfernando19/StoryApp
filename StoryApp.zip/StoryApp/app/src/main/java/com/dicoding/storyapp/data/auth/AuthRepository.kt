package com.dicoding.storyapp.data.auth

import com.dicoding.storyapp.data.Api.ApiService
import com.dicoding.storyapp.data.model.LoginRequest
import com.dicoding.storyapp.data.model.SignupRequest
import retrofit2.Response

class AuthRepository(private val apiService: ApiService) {

    suspend fun signup(name: String, email: String, password: String): Response<AuthResponse> {
        // Membuat objek SignupRequest dan mengirimkannya ke apiService
        val signupRequest = SignupRequest(name, email, password)
        return apiService.signup(signupRequest)
    }

    suspend fun login(email: String, password: String): Response<AuthResponse> {
        // Membuat objek LoginRequest dan mengirimkannya ke apiService
        val loginRequest = LoginRequest(email, password)
        return apiService.login(loginRequest)
    }
}

