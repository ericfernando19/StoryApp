package com.dicoding.storyapp.data.model

data class SignupRequest(
    val name: String,
    val email: String,
    val password: String
)