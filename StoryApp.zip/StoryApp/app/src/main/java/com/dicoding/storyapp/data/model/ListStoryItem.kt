package com.dicoding.storyapp.data.model


import com.google.gson.annotations.SerializedName

// Data model untuk item story
data class ListStoryItem(
    @field:SerializedName("id")
    val id: String,

    @field:SerializedName("name")
    val name: String,

    @field:SerializedName("description")
    val description: String,

    @field:SerializedName("photoUrl")
    val photoUrl: String,

    @field:SerializedName("createdAt")
    val createdAt: String,

    @field:SerializedName("lat")
    val lat: Double, // Mengubah ke tipe Double non-nullable

    @field:SerializedName("lon")
    val lon: Double // Mengubah ke tipe Double non-nullable
)