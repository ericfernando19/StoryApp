package com.dicoding.storyapp.view.login

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.dicoding.storyapp.data.api.RetrofitInstance
import com.dicoding.storyapp.data.auth.AuthRepository
import com.dicoding.storyapp.databinding.ActivityLoginBinding
import com.dicoding.storyapp.ui.auth.AuthViewModel
import com.dicoding.storyapp.ui.auth.AuthViewModelFactory

class LoginActivity : AppCompatActivity() {

    private lateinit var authViewModel: AuthViewModel
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inisialisasi AuthRepository
        val authRepository = AuthRepository(RetrofitInstance.apiService)

        // Inisialisasi ViewModel menggunakan AuthViewModelFactory
        val factory = AuthViewModelFactory(authRepository, this)
        authViewModel = ViewModelProvider(this, factory).get(AuthViewModel::class.java)

        // Observe login response
        authViewModel.loginResponse.observe(this, Observer { response ->
            if (!response.error) {
                // Login berhasil
                Toast.makeText(this, "Login berhasil", Toast.LENGTH_SHORT).show()

                // Simpan token ke SharedPreferences
                authViewModel.saveToken(response.token)

                // Arahkan ke layar lain (misalnya, HomeActivity)
                finish()
            } else {
                // Login gagal, tampilkan pesan error
                Toast.makeText(this, "Login gagal: ${response.message}", Toast.LENGTH_SHORT).show()
            }
        })

        setupAction()
        setupPasswordValidation()
    }

    private fun setupAction() {
        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            // Validasi input
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan password harus diisi!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Panggil login dengan ViewModel
            authViewModel.login(email, password)
        }
    }

    private fun setupPasswordValidation() {
        binding.passwordEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Tidak digunakan
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s != null && s.length < 8) {
                    binding.passwordEditText.error = "Password tidak boleh kurang dari 8 karakter"
                } else {
                    binding.passwordEditText.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
                // Tidak digunakan
            }
        })
    }
}
