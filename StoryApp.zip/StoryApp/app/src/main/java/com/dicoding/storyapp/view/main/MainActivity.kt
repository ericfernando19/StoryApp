package com.dicoding.storyapp.view.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.storyapp.R
import com.dicoding.storyapp.databinding.ActivityMainBinding
import com.dicoding.storyapp.view.ViewModelFactory
import com.dicoding.storyapp.view.welcome.WelcomeActivity

class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Observe session status to check login state
        viewModel.getSession().observe(this) { user ->
            // Add logging for debugging
            Log.d("MainActivity", "User session: $user")

            // Check if user is logged in
            if (user == null || !user.isLogin) {
                Log.d("MainActivity", "User is not logged in, navigating to WelcomeActivity")
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }
        }

        // Setup the view (full screen)
        setupView()

        // Handle actions like logout
        setupAction()
    }

    private fun setupView() {
        // Handle full screen mode
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        // Handle logout button click
        binding.logoutButton.setOnClickListener {
            Log.d("MainActivity", "Logging out...")
            viewModel.logout()
        }
    }
}
