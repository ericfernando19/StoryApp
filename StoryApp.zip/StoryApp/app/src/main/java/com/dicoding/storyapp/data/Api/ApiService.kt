package com.dicoding.storyapp.data.Api

import com.dicoding.storyapp.data.auth.AuthResponse
import com.dicoding.storyapp.data.model.LoginRequest
import com.dicoding.storyapp.data.model.SignupRequest
import com.dicoding.storyapp.data.model.StoryResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface ApiService {

    @POST("signup")
    suspend fun signup(@Body signupRequest: SignupRequest): Response<AuthResponse>

    @POST("login")
    suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>

    @GET("stories")
    suspend fun getStories(@Header("Authorization") token: String): StoryResponse
}

